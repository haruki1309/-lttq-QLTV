﻿namespace GraphicUserInterface
{
    partial class frmDocGia
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel15 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.mainbtnCaiDat = new System.Windows.Forms.Button();
            this.mainbtnQuyDinh = new System.Windows.Forms.Button();
            this.mainbtnThongKe = new System.Windows.Forms.Button();
            this.mainbtnNhanTraSach = new System.Windows.Forms.Button();
            this.mainbtnChoMuonSach = new System.Windows.Forms.Button();
            this.mainbtnDocGia = new System.Windows.Forms.Button();
            this.mainbtnKhoSach = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.pnltabDocGia = new System.Windows.Forms.Panel();
            this.dgvDocGia = new System.Windows.Forms.DataGridView();
            this.pnlThongTinDocGia = new System.Windows.Forms.Panel();
            this.pnlThongBaoDocGia = new System.Windows.Forms.Panel();
            this.lblTitleThongBaoDocGia = new System.Windows.Forms.Label();
            this.lblThongBaoDocGia = new System.Windows.Forms.Label();
            this.btnHuyThaoTacDocGia = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.dtmNgayDKDocGia = new System.Windows.Forms.DateTimePicker();
            this.dtmNgaySinhDocGia = new System.Windows.Forms.DateTimePicker();
            this.txtCMNDDocGia = new System.Windows.Forms.TextBox();
            this.txtSDTDocGia = new System.Windows.Forms.TextBox();
            this.btnSuaDocGia = new System.Windows.Forms.Button();
            this.btnXoaDocGia = new System.Windows.Forms.Button();
            this.txtDiaChiDocGia = new System.Windows.Forms.TextBox();
            this.btnThemDocGia = new System.Windows.Forms.Button();
            this.txtHoTenDocGia = new System.Windows.Forms.TextBox();
            this.lblNgayDK = new System.Windows.Forms.Label();
            this.lblNgaySinh = new System.Windows.Forms.Label();
            this.lblSDT = new System.Windows.Forms.Label();
            this.lblCMND = new System.Windows.Forms.Label();
            this.lblDiaChi = new System.Windows.Forms.Label();
            this.lblHoTen = new System.Windows.Forms.Label();
            this.pnlBoLoc = new System.Windows.Forms.Panel();
            this.btnLoc = new System.Windows.Forms.Button();
            this.chkNgayDK = new System.Windows.Forms.CheckBox();
            this.chkNgaySinh = new System.Windows.Forms.CheckBox();
            this.chkCMND = new System.Windows.Forms.CheckBox();
            this.chkSDT = new System.Windows.Forms.CheckBox();
            this.chkDiaChi = new System.Windows.Forms.CheckBox();
            this.lblTuaDe = new System.Windows.Forms.Label();
            this.pnlSearchFor = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lblTimKiem = new System.Windows.Forms.Label();
            this.btnSearchFor = new System.Windows.Forms.Button();
            this.cboSearchFor = new System.Windows.Forms.ComboBox();
            this.pnlTacVu = new System.Windows.Forms.Panel();
            this.pnlHightLightTimKiem = new System.Windows.Forms.Panel();
            this.pnlHightLightBoLoc = new System.Windows.Forms.Panel();
            this.tabbtnTimKiemDocGia = new System.Windows.Forms.Button();
            this.tabbtnBoLocDocGia = new System.Windows.Forms.Button();
            this.pnltabKhoSach = new System.Windows.Forms.Panel();
            this.dgvSach = new System.Windows.Forms.DataGridView();
            this.pnlThongTinSach = new System.Windows.Forms.Panel();
            this.dtmNgayNhap = new System.Windows.Forms.DateTimePicker();
            this.txtMaTheLoai = new System.Windows.Forms.TextBox();
            this.lblNgayNhap = new System.Windows.Forms.Label();
            this.lblMaTheLoai = new System.Windows.Forms.Label();
            this.txtMaChuDe = new System.Windows.Forms.TextBox();
            this.lblMaChuDe = new System.Windows.Forms.Label();
            this.txtGiaTri = new System.Windows.Forms.TextBox();
            this.txtSoLuong = new System.Windows.Forms.TextBox();
            this.lblSoLuong = new System.Windows.Forms.Label();
            this.txtNhaPhatHanh = new System.Windows.Forms.TextBox();
            this.pnlThongBaoSach = new System.Windows.Forms.Panel();
            this.lblThongBaoSach = new System.Windows.Forms.Label();
            this.lblTitleThongBaoSach = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnHuyCapNhatSach = new System.Windows.Forms.Button();
            this.lblCapNhatDocGia = new System.Windows.Forms.Label();
            this.txtNXB = new System.Windows.Forms.TextBox();
            this.txtNamXB = new System.Windows.Forms.TextBox();
            this.btnSuaSach = new System.Windows.Forms.Button();
            this.btnXoaSach = new System.Windows.Forms.Button();
            this.txtTacGia = new System.Windows.Forms.TextBox();
            this.btnThemSach = new System.Windows.Forms.Button();
            this.txtTenSach = new System.Windows.Forms.TextBox();
            this.lblGiaTri = new System.Windows.Forms.Label();
            this.lblNhaPhatHanh = new System.Windows.Forms.Label();
            this.lblNamXB = new System.Windows.Forms.Label();
            this.lblNXB = new System.Windows.Forms.Label();
            this.lblTacGia = new System.Windows.Forms.Label();
            this.lblTenSach = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.button5 = new System.Windows.Forms.Button();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.label11 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.panel9 = new System.Windows.Forms.Panel();
            this.pnlHighLightTimKiemSach = new System.Windows.Forms.Panel();
            this.pnlHighLightBoLoc = new System.Windows.Forms.Panel();
            this.tabbtnTimKiemSach = new System.Windows.Forms.Button();
            this.tabbtnBoLocSach = new System.Windows.Forms.Button();
            this.panel3.SuspendLayout();
            this.pnltabDocGia.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDocGia)).BeginInit();
            this.pnlThongTinDocGia.SuspendLayout();
            this.pnlThongBaoDocGia.SuspendLayout();
            this.pnlBoLoc.SuspendLayout();
            this.pnlSearchFor.SuspendLayout();
            this.pnlTacVu.SuspendLayout();
            this.pnltabKhoSach.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSach)).BeginInit();
            this.pnlThongTinSach.SuspendLayout();
            this.pnlThongBaoSach.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel6
            // 
            this.panel6.Location = new System.Drawing.Point(0, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(200, 100);
            this.panel6.TabIndex = 0;
            // 
            // panel12
            // 
            this.panel12.Location = new System.Drawing.Point(0, 0);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(200, 100);
            this.panel12.TabIndex = 0;
            // 
            // panel15
            // 
            this.panel15.Location = new System.Drawing.Point(0, 0);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(200, 100);
            this.panel15.TabIndex = 0;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(54)))), ((int)(((byte)(50)))));
            this.panel3.Controls.Add(this.mainbtnCaiDat);
            this.panel3.Controls.Add(this.mainbtnQuyDinh);
            this.panel3.Controls.Add(this.mainbtnThongKe);
            this.panel3.Controls.Add(this.mainbtnNhanTraSach);
            this.panel3.Controls.Add(this.mainbtnChoMuonSach);
            this.panel3.Controls.Add(this.mainbtnDocGia);
            this.panel3.Controls.Add(this.mainbtnKhoSach);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(150, 572);
            this.panel3.TabIndex = 27;
            // 
            // mainbtnCaiDat
            // 
            this.mainbtnCaiDat.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.mainbtnCaiDat.FlatAppearance.BorderSize = 0;
            this.mainbtnCaiDat.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DimGray;
            this.mainbtnCaiDat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mainbtnCaiDat.Font = new System.Drawing.Font("Sitka Heading", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.mainbtnCaiDat.ForeColor = System.Drawing.Color.White;
            this.mainbtnCaiDat.Location = new System.Drawing.Point(15, 330);
            this.mainbtnCaiDat.Name = "mainbtnCaiDat";
            this.mainbtnCaiDat.Size = new System.Drawing.Size(135, 40);
            this.mainbtnCaiDat.TabIndex = 34;
            this.mainbtnCaiDat.Text = "Cài Đặt";
            this.mainbtnCaiDat.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.mainbtnCaiDat.UseVisualStyleBackColor = true;
            // 
            // mainbtnQuyDinh
            // 
            this.mainbtnQuyDinh.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.mainbtnQuyDinh.FlatAppearance.BorderSize = 0;
            this.mainbtnQuyDinh.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DimGray;
            this.mainbtnQuyDinh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mainbtnQuyDinh.Font = new System.Drawing.Font("Sitka Heading", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.mainbtnQuyDinh.ForeColor = System.Drawing.Color.White;
            this.mainbtnQuyDinh.Location = new System.Drawing.Point(15, 290);
            this.mainbtnQuyDinh.Name = "mainbtnQuyDinh";
            this.mainbtnQuyDinh.Size = new System.Drawing.Size(135, 40);
            this.mainbtnQuyDinh.TabIndex = 33;
            this.mainbtnQuyDinh.Text = "Quy Định";
            this.mainbtnQuyDinh.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.mainbtnQuyDinh.UseVisualStyleBackColor = true;
            // 
            // mainbtnThongKe
            // 
            this.mainbtnThongKe.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.mainbtnThongKe.FlatAppearance.BorderSize = 0;
            this.mainbtnThongKe.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DimGray;
            this.mainbtnThongKe.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mainbtnThongKe.Font = new System.Drawing.Font("Sitka Heading", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.mainbtnThongKe.ForeColor = System.Drawing.Color.White;
            this.mainbtnThongKe.Location = new System.Drawing.Point(15, 250);
            this.mainbtnThongKe.Name = "mainbtnThongKe";
            this.mainbtnThongKe.Size = new System.Drawing.Size(135, 40);
            this.mainbtnThongKe.TabIndex = 32;
            this.mainbtnThongKe.Text = "Thống Kê";
            this.mainbtnThongKe.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.mainbtnThongKe.UseVisualStyleBackColor = true;
            // 
            // mainbtnNhanTraSach
            // 
            this.mainbtnNhanTraSach.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.mainbtnNhanTraSach.FlatAppearance.BorderSize = 0;
            this.mainbtnNhanTraSach.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DimGray;
            this.mainbtnNhanTraSach.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mainbtnNhanTraSach.Font = new System.Drawing.Font("Sitka Heading", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.mainbtnNhanTraSach.ForeColor = System.Drawing.Color.White;
            this.mainbtnNhanTraSach.Location = new System.Drawing.Point(15, 210);
            this.mainbtnNhanTraSach.Name = "mainbtnNhanTraSach";
            this.mainbtnNhanTraSach.Size = new System.Drawing.Size(135, 40);
            this.mainbtnNhanTraSach.TabIndex = 31;
            this.mainbtnNhanTraSach.Text = "Nhận Trả Sách";
            this.mainbtnNhanTraSach.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.mainbtnNhanTraSach.UseVisualStyleBackColor = true;
            // 
            // mainbtnChoMuonSach
            // 
            this.mainbtnChoMuonSach.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.mainbtnChoMuonSach.FlatAppearance.BorderSize = 0;
            this.mainbtnChoMuonSach.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DimGray;
            this.mainbtnChoMuonSach.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mainbtnChoMuonSach.Font = new System.Drawing.Font("Sitka Heading", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.mainbtnChoMuonSach.ForeColor = System.Drawing.Color.White;
            this.mainbtnChoMuonSach.Location = new System.Drawing.Point(15, 170);
            this.mainbtnChoMuonSach.Name = "mainbtnChoMuonSach";
            this.mainbtnChoMuonSach.Size = new System.Drawing.Size(135, 40);
            this.mainbtnChoMuonSach.TabIndex = 30;
            this.mainbtnChoMuonSach.Text = "Cho Mượn Sách";
            this.mainbtnChoMuonSach.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.mainbtnChoMuonSach.UseVisualStyleBackColor = true;
            // 
            // mainbtnDocGia
            // 
            this.mainbtnDocGia.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.mainbtnDocGia.FlatAppearance.BorderSize = 0;
            this.mainbtnDocGia.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DimGray;
            this.mainbtnDocGia.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mainbtnDocGia.Font = new System.Drawing.Font("Sitka Heading", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.mainbtnDocGia.ForeColor = System.Drawing.Color.White;
            this.mainbtnDocGia.Location = new System.Drawing.Point(15, 130);
            this.mainbtnDocGia.Name = "mainbtnDocGia";
            this.mainbtnDocGia.Size = new System.Drawing.Size(135, 40);
            this.mainbtnDocGia.TabIndex = 29;
            this.mainbtnDocGia.Text = "Độc Giả";
            this.mainbtnDocGia.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.mainbtnDocGia.UseVisualStyleBackColor = true;
            this.mainbtnDocGia.Click += new System.EventHandler(this.mainbtnDocGia_Click);
            // 
            // mainbtnKhoSach
            // 
            this.mainbtnKhoSach.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.mainbtnKhoSach.FlatAppearance.BorderSize = 0;
            this.mainbtnKhoSach.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DimGray;
            this.mainbtnKhoSach.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mainbtnKhoSach.Font = new System.Drawing.Font("Sitka Heading", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.mainbtnKhoSach.ForeColor = System.Drawing.Color.White;
            this.mainbtnKhoSach.Location = new System.Drawing.Point(15, 90);
            this.mainbtnKhoSach.Name = "mainbtnKhoSach";
            this.mainbtnKhoSach.Size = new System.Drawing.Size(135, 40);
            this.mainbtnKhoSach.TabIndex = 28;
            this.mainbtnKhoSach.Text = "Kho Sách";
            this.mainbtnKhoSach.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.mainbtnKhoSach.UseVisualStyleBackColor = true;
            this.mainbtnKhoSach.Click += new System.EventHandler(this.mainbtnKhoSach_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(104)))), ((int)(((byte)(57)))));
            this.panel4.Location = new System.Drawing.Point(150, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(871, 10);
            this.panel4.TabIndex = 28;
            // 
            // pnltabDocGia
            // 
            this.pnltabDocGia.Controls.Add(this.dgvDocGia);
            this.pnltabDocGia.Controls.Add(this.pnlThongTinDocGia);
            this.pnltabDocGia.Controls.Add(this.pnlBoLoc);
            this.pnltabDocGia.Controls.Add(this.pnlSearchFor);
            this.pnltabDocGia.Controls.Add(this.pnlTacVu);
            this.pnltabDocGia.Location = new System.Drawing.Point(150, 57);
            this.pnltabDocGia.Name = "pnltabDocGia";
            this.pnltabDocGia.Size = new System.Drawing.Size(871, 515);
            this.pnltabDocGia.TabIndex = 29;
            // 
            // dgvDocGia
            // 
            this.dgvDocGia.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvDocGia.BackgroundColor = System.Drawing.Color.White;
            this.dgvDocGia.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(104)))), ((int)(((byte)(57)))));
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Sitka Heading", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            dataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(104)))), ((int)(((byte)(57)))));
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDocGia.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle13;
            this.dgvDocGia.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Sitka Display", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            dataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvDocGia.DefaultCellStyle = dataGridViewCellStyle14;
            this.dgvDocGia.Location = new System.Drawing.Point(415, 29);
            this.dgvDocGia.Name = "dgvDocGia";
            this.dgvDocGia.ReadOnly = true;
            this.dgvDocGia.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dgvDocGia.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvDocGia.Size = new System.Drawing.Size(453, 486);
            this.dgvDocGia.TabIndex = 36;
            this.dgvDocGia.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvDocGia_RowHeaderMouseClick);
            // 
            // pnlThongTinDocGia
            // 
            this.pnlThongTinDocGia.Controls.Add(this.pnlThongBaoDocGia);
            this.pnlThongTinDocGia.Controls.Add(this.btnHuyThaoTacDocGia);
            this.pnlThongTinDocGia.Controls.Add(this.label1);
            this.pnlThongTinDocGia.Controls.Add(this.dtmNgayDKDocGia);
            this.pnlThongTinDocGia.Controls.Add(this.dtmNgaySinhDocGia);
            this.pnlThongTinDocGia.Controls.Add(this.txtCMNDDocGia);
            this.pnlThongTinDocGia.Controls.Add(this.txtSDTDocGia);
            this.pnlThongTinDocGia.Controls.Add(this.btnSuaDocGia);
            this.pnlThongTinDocGia.Controls.Add(this.btnXoaDocGia);
            this.pnlThongTinDocGia.Controls.Add(this.txtDiaChiDocGia);
            this.pnlThongTinDocGia.Controls.Add(this.btnThemDocGia);
            this.pnlThongTinDocGia.Controls.Add(this.txtHoTenDocGia);
            this.pnlThongTinDocGia.Controls.Add(this.lblNgayDK);
            this.pnlThongTinDocGia.Controls.Add(this.lblNgaySinh);
            this.pnlThongTinDocGia.Controls.Add(this.lblSDT);
            this.pnlThongTinDocGia.Controls.Add(this.lblCMND);
            this.pnlThongTinDocGia.Controls.Add(this.lblDiaChi);
            this.pnlThongTinDocGia.Controls.Add(this.lblHoTen);
            this.pnlThongTinDocGia.Location = new System.Drawing.Point(0, 0);
            this.pnlThongTinDocGia.Name = "pnlThongTinDocGia";
            this.pnlThongTinDocGia.Size = new System.Drawing.Size(415, 473);
            this.pnlThongTinDocGia.TabIndex = 34;
            // 
            // pnlThongBaoDocGia
            // 
            this.pnlThongBaoDocGia.BackColor = System.Drawing.Color.White;
            this.pnlThongBaoDocGia.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlThongBaoDocGia.Controls.Add(this.lblTitleThongBaoDocGia);
            this.pnlThongBaoDocGia.Controls.Add(this.lblThongBaoDocGia);
            this.pnlThongBaoDocGia.Location = new System.Drawing.Point(37, 365);
            this.pnlThongBaoDocGia.Name = "pnlThongBaoDocGia";
            this.pnlThongBaoDocGia.Size = new System.Drawing.Size(236, 100);
            this.pnlThongBaoDocGia.TabIndex = 44;
            // 
            // lblTitleThongBaoDocGia
            // 
            this.lblTitleThongBaoDocGia.AutoSize = true;
            this.lblTitleThongBaoDocGia.Font = new System.Drawing.Font("Sitka Heading", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitleThongBaoDocGia.Location = new System.Drawing.Point(149, 75);
            this.lblTitleThongBaoDocGia.Name = "lblTitleThongBaoDocGia";
            this.lblTitleThongBaoDocGia.Size = new System.Drawing.Size(82, 21);
            this.lblTitleThongBaoDocGia.TabIndex = 43;
            this.lblTitleThongBaoDocGia.Text = "Thông Báo";
            // 
            // lblThongBaoDocGia
            // 
            this.lblThongBaoDocGia.AutoSize = true;
            this.lblThongBaoDocGia.Font = new System.Drawing.Font("Sitka Display", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblThongBaoDocGia.ForeColor = System.Drawing.Color.Red;
            this.lblThongBaoDocGia.Location = new System.Drawing.Point(6, 17);
            this.lblThongBaoDocGia.Name = "lblThongBaoDocGia";
            this.lblThongBaoDocGia.Size = new System.Drawing.Size(0, 21);
            this.lblThongBaoDocGia.TabIndex = 42;
            // 
            // btnHuyThaoTacDocGia
            // 
            this.btnHuyThaoTacDocGia.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(104)))), ((int)(((byte)(57)))));
            this.btnHuyThaoTacDocGia.Enabled = false;
            this.btnHuyThaoTacDocGia.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnHuyThaoTacDocGia.FlatAppearance.BorderSize = 0;
            this.btnHuyThaoTacDocGia.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(130)))), ((int)(((byte)(71)))));
            this.btnHuyThaoTacDocGia.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(121)))), ((int)(((byte)(66)))));
            this.btnHuyThaoTacDocGia.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHuyThaoTacDocGia.Font = new System.Drawing.Font("Sitka Display", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnHuyThaoTacDocGia.Location = new System.Drawing.Point(293, 365);
            this.btnHuyThaoTacDocGia.Name = "btnHuyThaoTacDocGia";
            this.btnHuyThaoTacDocGia.Size = new System.Drawing.Size(108, 38);
            this.btnHuyThaoTacDocGia.TabIndex = 43;
            this.btnHuyThaoTacDocGia.Text = "Hủy";
            this.btnHuyThaoTacDocGia.UseVisualStyleBackColor = false;
            this.btnHuyThaoTacDocGia.Click += new System.EventHandler(this.btnHuyThaoTacDocGia_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Sitka Heading", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.Location = new System.Drawing.Point(16, 262);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 30);
            this.label1.TabIndex = 40;
            this.label1.Text = "Cập Nhật";
            // 
            // dtmNgayDKDocGia
            // 
            this.dtmNgayDKDocGia.Font = new System.Drawing.Font("Sitka Display", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dtmNgayDKDocGia.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtmNgayDKDocGia.Location = new System.Drawing.Point(170, 212);
            this.dtmNgayDKDocGia.Name = "dtmNgayDKDocGia";
            this.dtmNgayDKDocGia.Size = new System.Drawing.Size(231, 28);
            this.dtmNgayDKDocGia.TabIndex = 38;
            // 
            // dtmNgaySinhDocGia
            // 
            this.dtmNgaySinhDocGia.Font = new System.Drawing.Font("Sitka Display", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dtmNgaySinhDocGia.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtmNgaySinhDocGia.Location = new System.Drawing.Point(170, 175);
            this.dtmNgaySinhDocGia.Name = "dtmNgaySinhDocGia";
            this.dtmNgaySinhDocGia.Size = new System.Drawing.Size(231, 28);
            this.dtmNgaySinhDocGia.TabIndex = 37;
            // 
            // txtCMNDDocGia
            // 
            this.txtCMNDDocGia.Font = new System.Drawing.Font("Sitka Display", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtCMNDDocGia.Location = new System.Drawing.Point(170, 141);
            this.txtCMNDDocGia.Name = "txtCMNDDocGia";
            this.txtCMNDDocGia.Size = new System.Drawing.Size(231, 28);
            this.txtCMNDDocGia.TabIndex = 9;
            // 
            // txtSDTDocGia
            // 
            this.txtSDTDocGia.Font = new System.Drawing.Font("Sitka Display", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtSDTDocGia.Location = new System.Drawing.Point(170, 103);
            this.txtSDTDocGia.Name = "txtSDTDocGia";
            this.txtSDTDocGia.Size = new System.Drawing.Size(231, 28);
            this.txtSDTDocGia.TabIndex = 8;
            // 
            // btnSuaDocGia
            // 
            this.btnSuaDocGia.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(104)))), ((int)(((byte)(57)))));
            this.btnSuaDocGia.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnSuaDocGia.FlatAppearance.BorderSize = 0;
            this.btnSuaDocGia.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(130)))), ((int)(((byte)(71)))));
            this.btnSuaDocGia.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(121)))), ((int)(((byte)(66)))));
            this.btnSuaDocGia.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSuaDocGia.Font = new System.Drawing.Font("Sitka Display", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnSuaDocGia.Location = new System.Drawing.Point(165, 300);
            this.btnSuaDocGia.Name = "btnSuaDocGia";
            this.btnSuaDocGia.Size = new System.Drawing.Size(108, 38);
            this.btnSuaDocGia.TabIndex = 13;
            this.btnSuaDocGia.Text = "Sửa";
            this.btnSuaDocGia.UseVisualStyleBackColor = false;
            this.btnSuaDocGia.Click += new System.EventHandler(this.btnSuaDocGia_Click);
            // 
            // btnXoaDocGia
            // 
            this.btnXoaDocGia.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(104)))), ((int)(((byte)(57)))));
            this.btnXoaDocGia.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnXoaDocGia.FlatAppearance.BorderSize = 0;
            this.btnXoaDocGia.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(130)))), ((int)(((byte)(71)))));
            this.btnXoaDocGia.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(121)))), ((int)(((byte)(66)))));
            this.btnXoaDocGia.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnXoaDocGia.Font = new System.Drawing.Font("Sitka Display", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnXoaDocGia.Location = new System.Drawing.Point(293, 300);
            this.btnXoaDocGia.Name = "btnXoaDocGia";
            this.btnXoaDocGia.Size = new System.Drawing.Size(108, 38);
            this.btnXoaDocGia.TabIndex = 14;
            this.btnXoaDocGia.Text = "Xóa";
            this.btnXoaDocGia.UseVisualStyleBackColor = false;
            this.btnXoaDocGia.Click += new System.EventHandler(this.btnXoaDocGia_Click);
            // 
            // txtDiaChiDocGia
            // 
            this.txtDiaChiDocGia.Font = new System.Drawing.Font("Sitka Display", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtDiaChiDocGia.Location = new System.Drawing.Point(170, 66);
            this.txtDiaChiDocGia.Name = "txtDiaChiDocGia";
            this.txtDiaChiDocGia.Size = new System.Drawing.Size(231, 28);
            this.txtDiaChiDocGia.TabIndex = 7;
            // 
            // btnThemDocGia
            // 
            this.btnThemDocGia.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(104)))), ((int)(((byte)(57)))));
            this.btnThemDocGia.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnThemDocGia.FlatAppearance.BorderSize = 0;
            this.btnThemDocGia.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(130)))), ((int)(((byte)(71)))));
            this.btnThemDocGia.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(121)))), ((int)(((byte)(66)))));
            this.btnThemDocGia.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThemDocGia.Font = new System.Drawing.Font("Sitka Display", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnThemDocGia.Location = new System.Drawing.Point(37, 300);
            this.btnThemDocGia.Name = "btnThemDocGia";
            this.btnThemDocGia.Size = new System.Drawing.Size(108, 38);
            this.btnThemDocGia.TabIndex = 12;
            this.btnThemDocGia.Text = "Thêm";
            this.btnThemDocGia.UseVisualStyleBackColor = false;
            this.btnThemDocGia.Click += new System.EventHandler(this.btnThemDocGia_Click);
            // 
            // txtHoTenDocGia
            // 
            this.txtHoTenDocGia.Font = new System.Drawing.Font("Sitka Display", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtHoTenDocGia.Location = new System.Drawing.Point(170, 29);
            this.txtHoTenDocGia.Name = "txtHoTenDocGia";
            this.txtHoTenDocGia.Size = new System.Drawing.Size(231, 28);
            this.txtHoTenDocGia.TabIndex = 6;
            // 
            // lblNgayDK
            // 
            this.lblNgayDK.AutoSize = true;
            this.lblNgayDK.Font = new System.Drawing.Font("Sitka Heading", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblNgayDK.Location = new System.Drawing.Point(56, 217);
            this.lblNgayDK.Name = "lblNgayDK";
            this.lblNgayDK.Size = new System.Drawing.Size(108, 23);
            this.lblNgayDK.TabIndex = 5;
            this.lblNgayDK.Text = "Ngày Đăng Ký";
            // 
            // lblNgaySinh
            // 
            this.lblNgaySinh.AutoSize = true;
            this.lblNgaySinh.Font = new System.Drawing.Font("Sitka Heading", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblNgaySinh.Location = new System.Drawing.Point(83, 180);
            this.lblNgaySinh.Name = "lblNgaySinh";
            this.lblNgaySinh.Size = new System.Drawing.Size(81, 23);
            this.lblNgaySinh.TabIndex = 4;
            this.lblNgaySinh.Text = "Ngày Sinh";
            // 
            // lblSDT
            // 
            this.lblSDT.AutoSize = true;
            this.lblSDT.Font = new System.Drawing.Font("Sitka Heading", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblSDT.Location = new System.Drawing.Point(124, 106);
            this.lblSDT.Name = "lblSDT";
            this.lblSDT.Size = new System.Drawing.Size(40, 23);
            this.lblSDT.TabIndex = 3;
            this.lblSDT.Text = "SDT";
            // 
            // lblCMND
            // 
            this.lblCMND.AutoSize = true;
            this.lblCMND.Font = new System.Drawing.Font("Sitka Heading", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblCMND.Location = new System.Drawing.Point(33, 144);
            this.lblCMND.Name = "lblCMND";
            this.lblCMND.Size = new System.Drawing.Size(131, 23);
            this.lblCMND.TabIndex = 2;
            this.lblCMND.Text = "Chứng Minh Thư";
            // 
            // lblDiaChi
            // 
            this.lblDiaChi.AutoSize = true;
            this.lblDiaChi.Font = new System.Drawing.Font("Sitka Heading", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblDiaChi.Location = new System.Drawing.Point(103, 69);
            this.lblDiaChi.Name = "lblDiaChi";
            this.lblDiaChi.Size = new System.Drawing.Size(61, 23);
            this.lblDiaChi.TabIndex = 1;
            this.lblDiaChi.Text = "Địa Chỉ";
            // 
            // lblHoTen
            // 
            this.lblHoTen.AutoSize = true;
            this.lblHoTen.Font = new System.Drawing.Font("Sitka Heading", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblHoTen.Location = new System.Drawing.Point(104, 32);
            this.lblHoTen.Name = "lblHoTen";
            this.lblHoTen.Size = new System.Drawing.Size(60, 23);
            this.lblHoTen.TabIndex = 0;
            this.lblHoTen.Text = "Họ Tên";
            // 
            // pnlBoLoc
            // 
            this.pnlBoLoc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(54)))), ((int)(((byte)(50)))));
            this.pnlBoLoc.Controls.Add(this.btnLoc);
            this.pnlBoLoc.Controls.Add(this.chkNgayDK);
            this.pnlBoLoc.Controls.Add(this.chkNgaySinh);
            this.pnlBoLoc.Controls.Add(this.chkCMND);
            this.pnlBoLoc.Controls.Add(this.chkSDT);
            this.pnlBoLoc.Controls.Add(this.chkDiaChi);
            this.pnlBoLoc.Controls.Add(this.lblTuaDe);
            this.pnlBoLoc.Location = new System.Drawing.Point(6, 261);
            this.pnlBoLoc.Name = "pnlBoLoc";
            this.pnlBoLoc.Size = new System.Drawing.Size(400, 211);
            this.pnlBoLoc.TabIndex = 35;
            // 
            // btnLoc
            // 
            this.btnLoc.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnLoc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLoc.Font = new System.Drawing.Font("Sitka Text", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnLoc.ForeColor = System.Drawing.Color.White;
            this.btnLoc.Location = new System.Drawing.Point(247, 148);
            this.btnLoc.Name = "btnLoc";
            this.btnLoc.Size = new System.Drawing.Size(104, 32);
            this.btnLoc.TabIndex = 6;
            this.btnLoc.Text = "Lọc";
            this.btnLoc.UseVisualStyleBackColor = true;
            this.btnLoc.Click += new System.EventHandler(this.btnLoc_Click);
            // 
            // chkNgayDK
            // 
            this.chkNgayDK.AutoSize = true;
            this.chkNgayDK.Checked = true;
            this.chkNgayDK.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkNgayDK.Font = new System.Drawing.Font("Sitka Subheading", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.chkNgayDK.ForeColor = System.Drawing.Color.White;
            this.chkNgayDK.Location = new System.Drawing.Point(202, 86);
            this.chkNgayDK.Name = "chkNgayDK";
            this.chkNgayDK.Size = new System.Drawing.Size(125, 25);
            this.chkNgayDK.TabIndex = 5;
            this.chkNgayDK.Text = "Ngày Đăng Ký";
            this.chkNgayDK.UseVisualStyleBackColor = true;
            // 
            // chkNgaySinh
            // 
            this.chkNgaySinh.AutoSize = true;
            this.chkNgaySinh.Checked = true;
            this.chkNgaySinh.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkNgaySinh.Font = new System.Drawing.Font("Sitka Subheading", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.chkNgaySinh.ForeColor = System.Drawing.Color.White;
            this.chkNgaySinh.Location = new System.Drawing.Point(202, 55);
            this.chkNgaySinh.Name = "chkNgaySinh";
            this.chkNgaySinh.Size = new System.Drawing.Size(97, 25);
            this.chkNgaySinh.TabIndex = 4;
            this.chkNgaySinh.Text = "Ngày Sinh";
            this.chkNgaySinh.UseVisualStyleBackColor = true;
            // 
            // chkCMND
            // 
            this.chkCMND.AutoSize = true;
            this.chkCMND.Checked = true;
            this.chkCMND.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkCMND.Font = new System.Drawing.Font("Sitka Subheading", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.chkCMND.ForeColor = System.Drawing.Color.White;
            this.chkCMND.Location = new System.Drawing.Point(41, 117);
            this.chkCMND.Name = "chkCMND";
            this.chkCMND.Size = new System.Drawing.Size(142, 25);
            this.chkCMND.TabIndex = 3;
            this.chkCMND.Text = "Chứng Minh Thư";
            this.chkCMND.UseVisualStyleBackColor = true;
            // 
            // chkSDT
            // 
            this.chkSDT.AutoSize = true;
            this.chkSDT.Checked = true;
            this.chkSDT.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkSDT.Font = new System.Drawing.Font("Sitka Subheading", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.chkSDT.ForeColor = System.Drawing.Color.White;
            this.chkSDT.Location = new System.Drawing.Point(41, 86);
            this.chkSDT.Name = "chkSDT";
            this.chkSDT.Size = new System.Drawing.Size(120, 25);
            this.chkSDT.TabIndex = 2;
            this.chkSDT.Text = "Số Điện Thoại";
            this.chkSDT.UseVisualStyleBackColor = true;
            // 
            // chkDiaChi
            // 
            this.chkDiaChi.AutoSize = true;
            this.chkDiaChi.Checked = true;
            this.chkDiaChi.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkDiaChi.Font = new System.Drawing.Font("Sitka Subheading", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.chkDiaChi.ForeColor = System.Drawing.Color.White;
            this.chkDiaChi.Location = new System.Drawing.Point(41, 55);
            this.chkDiaChi.Name = "chkDiaChi";
            this.chkDiaChi.Size = new System.Drawing.Size(76, 25);
            this.chkDiaChi.TabIndex = 1;
            this.chkDiaChi.Text = "Địa Chỉ";
            this.chkDiaChi.UseVisualStyleBackColor = true;
            // 
            // lblTuaDe
            // 
            this.lblTuaDe.AutoSize = true;
            this.lblTuaDe.Font = new System.Drawing.Font("Sitka Heading", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblTuaDe.ForeColor = System.Drawing.Color.White;
            this.lblTuaDe.Location = new System.Drawing.Point(20, 21);
            this.lblTuaDe.Name = "lblTuaDe";
            this.lblTuaDe.Size = new System.Drawing.Size(179, 28);
            this.lblTuaDe.TabIndex = 0;
            this.lblTuaDe.Text = "Thông Tin Cần Xem";
            // 
            // pnlSearchFor
            // 
            this.pnlSearchFor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(54)))), ((int)(((byte)(50)))));
            this.pnlSearchFor.Controls.Add(this.textBox1);
            this.pnlSearchFor.Controls.Add(this.lblTimKiem);
            this.pnlSearchFor.Controls.Add(this.btnSearchFor);
            this.pnlSearchFor.Controls.Add(this.cboSearchFor);
            this.pnlSearchFor.Location = new System.Drawing.Point(6, 261);
            this.pnlSearchFor.Name = "pnlSearchFor";
            this.pnlSearchFor.Size = new System.Drawing.Size(400, 212);
            this.pnlSearchFor.TabIndex = 34;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.White;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Font = new System.Drawing.Font("Sitka Text", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.textBox1.Location = new System.Drawing.Point(25, 63);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(181, 21);
            this.textBox1.TabIndex = 11;
            // 
            // lblTimKiem
            // 
            this.lblTimKiem.AutoSize = true;
            this.lblTimKiem.Font = new System.Drawing.Font("Sitka Heading", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblTimKiem.ForeColor = System.Drawing.Color.White;
            this.lblTimKiem.Location = new System.Drawing.Point(20, 22);
            this.lblTimKiem.Name = "lblTimKiem";
            this.lblTimKiem.Size = new System.Drawing.Size(95, 28);
            this.lblTimKiem.TabIndex = 10;
            this.lblTimKiem.Text = "Tìm Kiếm";
            // 
            // btnSearchFor
            // 
            this.btnSearchFor.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnSearchFor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSearchFor.Font = new System.Drawing.Font("Sitka Heading", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnSearchFor.ForeColor = System.Drawing.Color.White;
            this.btnSearchFor.Location = new System.Drawing.Point(240, 148);
            this.btnSearchFor.Name = "btnSearchFor";
            this.btnSearchFor.Size = new System.Drawing.Size(111, 36);
            this.btnSearchFor.TabIndex = 7;
            this.btnSearchFor.Text = "Tìm kiếm";
            this.btnSearchFor.UseVisualStyleBackColor = true;
            this.btnSearchFor.Click += new System.EventHandler(this.btnSearchFor_Click);
            // 
            // cboSearchFor
            // 
            this.cboSearchFor.BackColor = System.Drawing.Color.White;
            this.cboSearchFor.Font = new System.Drawing.Font("Sitka Text", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboSearchFor.FormattingEnabled = true;
            this.cboSearchFor.Items.AddRange(new object[] {
            "Mã độc giả",
            "Tên độc giả",
            "CMND",
            "Số điện thoại"});
            this.cboSearchFor.Location = new System.Drawing.Point(25, 90);
            this.cboSearchFor.Name = "cboSearchFor";
            this.cboSearchFor.Size = new System.Drawing.Size(123, 29);
            this.cboSearchFor.TabIndex = 8;
            this.cboSearchFor.Text = "Tìm kiếm theo";
            // 
            // pnlTacVu
            // 
            this.pnlTacVu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(54)))), ((int)(((byte)(50)))));
            this.pnlTacVu.Controls.Add(this.pnlHightLightTimKiem);
            this.pnlTacVu.Controls.Add(this.pnlHightLightBoLoc);
            this.pnlTacVu.Controls.Add(this.tabbtnTimKiemDocGia);
            this.pnlTacVu.Controls.Add(this.tabbtnBoLocDocGia);
            this.pnlTacVu.Location = new System.Drawing.Point(6, 475);
            this.pnlTacVu.Name = "pnlTacVu";
            this.pnlTacVu.Size = new System.Drawing.Size(400, 40);
            this.pnlTacVu.TabIndex = 33;
            // 
            // pnlHightLightTimKiem
            // 
            this.pnlHightLightTimKiem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(54)))), ((int)(((byte)(50)))));
            this.pnlHightLightTimKiem.Location = new System.Drawing.Point(0, 33);
            this.pnlHightLightTimKiem.Name = "pnlHightLightTimKiem";
            this.pnlHightLightTimKiem.Size = new System.Drawing.Size(200, 7);
            this.pnlHightLightTimKiem.TabIndex = 35;
            // 
            // pnlHightLightBoLoc
            // 
            this.pnlHightLightBoLoc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(54)))), ((int)(((byte)(50)))));
            this.pnlHightLightBoLoc.Location = new System.Drawing.Point(202, 33);
            this.pnlHightLightBoLoc.Name = "pnlHightLightBoLoc";
            this.pnlHightLightBoLoc.Size = new System.Drawing.Size(200, 7);
            this.pnlHightLightBoLoc.TabIndex = 36;
            // 
            // tabbtnTimKiemDocGia
            // 
            this.tabbtnTimKiemDocGia.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(54)))), ((int)(((byte)(50)))));
            this.tabbtnTimKiemDocGia.FlatAppearance.BorderSize = 0;
            this.tabbtnTimKiemDocGia.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.tabbtnTimKiemDocGia.Font = new System.Drawing.Font("Sitka Subheading", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.tabbtnTimKiemDocGia.ForeColor = System.Drawing.Color.White;
            this.tabbtnTimKiemDocGia.Location = new System.Drawing.Point(0, 0);
            this.tabbtnTimKiemDocGia.Name = "tabbtnTimKiemDocGia";
            this.tabbtnTimKiemDocGia.Size = new System.Drawing.Size(200, 33);
            this.tabbtnTimKiemDocGia.TabIndex = 29;
            this.tabbtnTimKiemDocGia.Text = "Tìm Kiếm";
            this.tabbtnTimKiemDocGia.UseVisualStyleBackColor = false;
            this.tabbtnTimKiemDocGia.Click += new System.EventHandler(this.tabbtnTimKiem_Click);
            // 
            // tabbtnBoLocDocGia
            // 
            this.tabbtnBoLocDocGia.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(54)))), ((int)(((byte)(50)))));
            this.tabbtnBoLocDocGia.FlatAppearance.BorderSize = 0;
            this.tabbtnBoLocDocGia.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.tabbtnBoLocDocGia.Font = new System.Drawing.Font("Sitka Subheading", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.tabbtnBoLocDocGia.ForeColor = System.Drawing.Color.White;
            this.tabbtnBoLocDocGia.Location = new System.Drawing.Point(200, 0);
            this.tabbtnBoLocDocGia.Name = "tabbtnBoLocDocGia";
            this.tabbtnBoLocDocGia.Size = new System.Drawing.Size(200, 33);
            this.tabbtnBoLocDocGia.TabIndex = 30;
            this.tabbtnBoLocDocGia.Text = "Bộ Lọc";
            this.tabbtnBoLocDocGia.UseVisualStyleBackColor = false;
            this.tabbtnBoLocDocGia.Click += new System.EventHandler(this.tabbtnBoLoc_Click);
            // 
            // pnltabKhoSach
            // 
            this.pnltabKhoSach.Controls.Add(this.dgvSach);
            this.pnltabKhoSach.Controls.Add(this.pnlThongTinSach);
            this.pnltabKhoSach.Controls.Add(this.panel7);
            this.pnltabKhoSach.Controls.Add(this.panel8);
            this.pnltabKhoSach.Controls.Add(this.panel9);
            this.pnltabKhoSach.Location = new System.Drawing.Point(150, 57);
            this.pnltabKhoSach.Name = "pnltabKhoSach";
            this.pnltabKhoSach.Size = new System.Drawing.Size(871, 515);
            this.pnltabKhoSach.TabIndex = 37;
            // 
            // dgvSach
            // 
            this.dgvSach.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvSach.BackgroundColor = System.Drawing.Color.White;
            this.dgvSach.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(104)))), ((int)(((byte)(57)))));
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Sitka Heading", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            dataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(104)))), ((int)(((byte)(57)))));
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvSach.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle15;
            this.dgvSach.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle16.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Sitka Display", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            dataGridViewCellStyle16.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvSach.DefaultCellStyle = dataGridViewCellStyle16;
            this.dgvSach.Location = new System.Drawing.Point(418, 26);
            this.dgvSach.Name = "dgvSach";
            this.dgvSach.ReadOnly = true;
            this.dgvSach.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dgvSach.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvSach.Size = new System.Drawing.Size(453, 486);
            this.dgvSach.TabIndex = 36;
            // 
            // pnlThongTinSach
            // 
            this.pnlThongTinSach.Controls.Add(this.dtmNgayNhap);
            this.pnlThongTinSach.Controls.Add(this.txtMaTheLoai);
            this.pnlThongTinSach.Controls.Add(this.lblNgayNhap);
            this.pnlThongTinSach.Controls.Add(this.lblMaTheLoai);
            this.pnlThongTinSach.Controls.Add(this.txtMaChuDe);
            this.pnlThongTinSach.Controls.Add(this.lblMaChuDe);
            this.pnlThongTinSach.Controls.Add(this.txtGiaTri);
            this.pnlThongTinSach.Controls.Add(this.txtSoLuong);
            this.pnlThongTinSach.Controls.Add(this.lblSoLuong);
            this.pnlThongTinSach.Controls.Add(this.txtNhaPhatHanh);
            this.pnlThongTinSach.Controls.Add(this.pnlThongBaoSach);
            this.pnlThongTinSach.Controls.Add(this.btnHuyCapNhatSach);
            this.pnlThongTinSach.Controls.Add(this.lblCapNhatDocGia);
            this.pnlThongTinSach.Controls.Add(this.txtNXB);
            this.pnlThongTinSach.Controls.Add(this.txtNamXB);
            this.pnlThongTinSach.Controls.Add(this.btnSuaSach);
            this.pnlThongTinSach.Controls.Add(this.btnXoaSach);
            this.pnlThongTinSach.Controls.Add(this.txtTacGia);
            this.pnlThongTinSach.Controls.Add(this.btnThemSach);
            this.pnlThongTinSach.Controls.Add(this.txtTenSach);
            this.pnlThongTinSach.Controls.Add(this.lblGiaTri);
            this.pnlThongTinSach.Controls.Add(this.lblNhaPhatHanh);
            this.pnlThongTinSach.Controls.Add(this.lblNamXB);
            this.pnlThongTinSach.Controls.Add(this.lblNXB);
            this.pnlThongTinSach.Controls.Add(this.lblTacGia);
            this.pnlThongTinSach.Controls.Add(this.lblTenSach);
            this.pnlThongTinSach.Location = new System.Drawing.Point(0, 0);
            this.pnlThongTinSach.Name = "pnlThongTinSach";
            this.pnlThongTinSach.Size = new System.Drawing.Size(415, 473);
            this.pnlThongTinSach.TabIndex = 34;
            // 
            // dtmNgayNhap
            // 
            this.dtmNgayNhap.Font = new System.Drawing.Font("Sitka Display", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.dtmNgayNhap.Location = new System.Drawing.Point(308, 89);
            this.dtmNgayNhap.Name = "dtmNgayNhap";
            this.dtmNgayNhap.Size = new System.Drawing.Size(102, 24);
            this.dtmNgayNhap.TabIndex = 54;
            this.dtmNgayNhap.Visible = false;
            // 
            // txtMaTheLoai
            // 
            this.txtMaTheLoai.Font = new System.Drawing.Font("Sitka Display", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtMaTheLoai.Location = new System.Drawing.Point(308, 52);
            this.txtMaTheLoai.Name = "txtMaTheLoai";
            this.txtMaTheLoai.Size = new System.Drawing.Size(102, 24);
            this.txtMaTheLoai.TabIndex = 53;
            this.txtMaTheLoai.Visible = false;
            // 
            // lblNgayNhap
            // 
            this.lblNgayNhap.AutoSize = true;
            this.lblNgayNhap.Font = new System.Drawing.Font("Sitka Heading", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblNgayNhap.Location = new System.Drawing.Point(227, 92);
            this.lblNgayNhap.Name = "lblNgayNhap";
            this.lblNgayNhap.Size = new System.Drawing.Size(72, 19);
            this.lblNgayNhap.TabIndex = 52;
            this.lblNgayNhap.Text = "Ngày Nhập";
            this.lblNgayNhap.Visible = false;
            // 
            // lblMaTheLoai
            // 
            this.lblMaTheLoai.AutoSize = true;
            this.lblMaTheLoai.Font = new System.Drawing.Font("Sitka Heading", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblMaTheLoai.Location = new System.Drawing.Point(227, 55);
            this.lblMaTheLoai.Name = "lblMaTheLoai";
            this.lblMaTheLoai.Size = new System.Drawing.Size(79, 19);
            this.lblMaTheLoai.TabIndex = 51;
            this.lblMaTheLoai.Text = "Mã Thể Loại";
            this.lblMaTheLoai.Visible = false;
            // 
            // txtMaChuDe
            // 
            this.txtMaChuDe.Font = new System.Drawing.Font("Sitka Display", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtMaChuDe.Location = new System.Drawing.Point(308, 15);
            this.txtMaChuDe.Name = "txtMaChuDe";
            this.txtMaChuDe.Size = new System.Drawing.Size(104, 24);
            this.txtMaChuDe.TabIndex = 50;
            this.txtMaChuDe.Visible = false;
            // 
            // lblMaChuDe
            // 
            this.lblMaChuDe.AutoSize = true;
            this.lblMaChuDe.Font = new System.Drawing.Font("Sitka Heading", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblMaChuDe.Location = new System.Drawing.Point(227, 18);
            this.lblMaChuDe.Name = "lblMaChuDe";
            this.lblMaChuDe.Size = new System.Drawing.Size(70, 19);
            this.lblMaChuDe.TabIndex = 49;
            this.lblMaChuDe.Text = "Mã Chủ Đề";
            this.lblMaChuDe.Visible = false;
            // 
            // txtGiaTri
            // 
            this.txtGiaTri.Font = new System.Drawing.Font("Sitka Display", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtGiaTri.Location = new System.Drawing.Point(165, 199);
            this.txtGiaTri.Name = "txtGiaTri";
            this.txtGiaTri.Size = new System.Drawing.Size(231, 28);
            this.txtGiaTri.TabIndex = 48;
            // 
            // txtSoLuong
            // 
            this.txtSoLuong.Font = new System.Drawing.Font("Sitka Display", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtSoLuong.Location = new System.Drawing.Point(165, 234);
            this.txtSoLuong.Name = "txtSoLuong";
            this.txtSoLuong.Size = new System.Drawing.Size(231, 28);
            this.txtSoLuong.TabIndex = 47;
            // 
            // lblSoLuong
            // 
            this.lblSoLuong.AutoSize = true;
            this.lblSoLuong.Font = new System.Drawing.Font("Sitka Heading", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblSoLuong.Location = new System.Drawing.Point(81, 237);
            this.lblSoLuong.Name = "lblSoLuong";
            this.lblSoLuong.Size = new System.Drawing.Size(78, 23);
            this.lblSoLuong.TabIndex = 46;
            this.lblSoLuong.Text = "Số Lượng";
            // 
            // txtNhaPhatHanh
            // 
            this.txtNhaPhatHanh.Font = new System.Drawing.Font("Sitka Display", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtNhaPhatHanh.Location = new System.Drawing.Point(165, 164);
            this.txtNhaPhatHanh.Name = "txtNhaPhatHanh";
            this.txtNhaPhatHanh.Size = new System.Drawing.Size(231, 28);
            this.txtNhaPhatHanh.TabIndex = 45;
            // 
            // pnlThongBaoSach
            // 
            this.pnlThongBaoSach.BackColor = System.Drawing.Color.White;
            this.pnlThongBaoSach.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlThongBaoSach.Controls.Add(this.lblThongBaoSach);
            this.pnlThongBaoSach.Controls.Add(this.lblTitleThongBaoSach);
            this.pnlThongBaoSach.Controls.Add(this.label3);
            this.pnlThongBaoSach.Location = new System.Drawing.Point(37, 365);
            this.pnlThongBaoSach.Name = "pnlThongBaoSach";
            this.pnlThongBaoSach.Size = new System.Drawing.Size(236, 100);
            this.pnlThongBaoSach.TabIndex = 44;
            // 
            // lblThongBaoSach
            // 
            this.lblThongBaoSach.AutoSize = true;
            this.lblThongBaoSach.Font = new System.Drawing.Font("Sitka Display", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblThongBaoSach.ForeColor = System.Drawing.Color.Red;
            this.lblThongBaoSach.Location = new System.Drawing.Point(19, 17);
            this.lblThongBaoSach.Name = "lblThongBaoSach";
            this.lblThongBaoSach.Size = new System.Drawing.Size(0, 21);
            this.lblThongBaoSach.TabIndex = 44;
            // 
            // lblTitleThongBaoSach
            // 
            this.lblTitleThongBaoSach.AutoSize = true;
            this.lblTitleThongBaoSach.Font = new System.Drawing.Font("Sitka Heading", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitleThongBaoSach.Location = new System.Drawing.Point(149, 75);
            this.lblTitleThongBaoSach.Name = "lblTitleThongBaoSach";
            this.lblTitleThongBaoSach.Size = new System.Drawing.Size(82, 21);
            this.lblTitleThongBaoSach.TabIndex = 43;
            this.lblTitleThongBaoSach.Text = "Thông Báo";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Sitka Display", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(6, 17);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 21);
            this.label3.TabIndex = 42;
            // 
            // btnHuyCapNhatSach
            // 
            this.btnHuyCapNhatSach.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(104)))), ((int)(((byte)(57)))));
            this.btnHuyCapNhatSach.Enabled = false;
            this.btnHuyCapNhatSach.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnHuyCapNhatSach.FlatAppearance.BorderSize = 0;
            this.btnHuyCapNhatSach.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(130)))), ((int)(((byte)(71)))));
            this.btnHuyCapNhatSach.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(121)))), ((int)(((byte)(66)))));
            this.btnHuyCapNhatSach.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHuyCapNhatSach.Font = new System.Drawing.Font("Sitka Display", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnHuyCapNhatSach.Location = new System.Drawing.Point(293, 365);
            this.btnHuyCapNhatSach.Name = "btnHuyCapNhatSach";
            this.btnHuyCapNhatSach.Size = new System.Drawing.Size(108, 38);
            this.btnHuyCapNhatSach.TabIndex = 43;
            this.btnHuyCapNhatSach.Text = "Hủy";
            this.btnHuyCapNhatSach.UseVisualStyleBackColor = false;
            // 
            // lblCapNhatDocGia
            // 
            this.lblCapNhatDocGia.AutoSize = true;
            this.lblCapNhatDocGia.Font = new System.Drawing.Font("Sitka Heading", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblCapNhatDocGia.Location = new System.Drawing.Point(16, 262);
            this.lblCapNhatDocGia.Name = "lblCapNhatDocGia";
            this.lblCapNhatDocGia.Size = new System.Drawing.Size(99, 30);
            this.lblCapNhatDocGia.TabIndex = 40;
            this.lblCapNhatDocGia.Text = "Cập Nhật";
            // 
            // txtNXB
            // 
            this.txtNXB.Font = new System.Drawing.Font("Sitka Display", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtNXB.Location = new System.Drawing.Point(165, 127);
            this.txtNXB.Name = "txtNXB";
            this.txtNXB.Size = new System.Drawing.Size(231, 28);
            this.txtNXB.TabIndex = 9;
            // 
            // txtNamXB
            // 
            this.txtNamXB.Font = new System.Drawing.Font("Sitka Display", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtNamXB.Location = new System.Drawing.Point(165, 89);
            this.txtNamXB.Name = "txtNamXB";
            this.txtNamXB.Size = new System.Drawing.Size(231, 28);
            this.txtNamXB.TabIndex = 8;
            // 
            // btnSuaSach
            // 
            this.btnSuaSach.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(104)))), ((int)(((byte)(57)))));
            this.btnSuaSach.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnSuaSach.FlatAppearance.BorderSize = 0;
            this.btnSuaSach.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(130)))), ((int)(((byte)(71)))));
            this.btnSuaSach.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(121)))), ((int)(((byte)(66)))));
            this.btnSuaSach.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSuaSach.Font = new System.Drawing.Font("Sitka Display", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnSuaSach.Location = new System.Drawing.Point(165, 300);
            this.btnSuaSach.Name = "btnSuaSach";
            this.btnSuaSach.Size = new System.Drawing.Size(108, 38);
            this.btnSuaSach.TabIndex = 13;
            this.btnSuaSach.Text = "Sửa";
            this.btnSuaSach.UseVisualStyleBackColor = false;
            this.btnSuaSach.Click += new System.EventHandler(this.btnSuaSach_Click);
            // 
            // btnXoaSach
            // 
            this.btnXoaSach.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(104)))), ((int)(((byte)(57)))));
            this.btnXoaSach.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnXoaSach.FlatAppearance.BorderSize = 0;
            this.btnXoaSach.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(130)))), ((int)(((byte)(71)))));
            this.btnXoaSach.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(121)))), ((int)(((byte)(66)))));
            this.btnXoaSach.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnXoaSach.Font = new System.Drawing.Font("Sitka Display", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnXoaSach.Location = new System.Drawing.Point(293, 300);
            this.btnXoaSach.Name = "btnXoaSach";
            this.btnXoaSach.Size = new System.Drawing.Size(108, 38);
            this.btnXoaSach.TabIndex = 14;
            this.btnXoaSach.Text = "Xóa";
            this.btnXoaSach.UseVisualStyleBackColor = false;
            this.btnXoaSach.Click += new System.EventHandler(this.btnXoaSach_Click);
            // 
            // txtTacGia
            // 
            this.txtTacGia.Font = new System.Drawing.Font("Sitka Display", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtTacGia.Location = new System.Drawing.Point(165, 52);
            this.txtTacGia.Name = "txtTacGia";
            this.txtTacGia.Size = new System.Drawing.Size(231, 28);
            this.txtTacGia.TabIndex = 7;
            // 
            // btnThemSach
            // 
            this.btnThemSach.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(104)))), ((int)(((byte)(57)))));
            this.btnThemSach.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnThemSach.FlatAppearance.BorderSize = 0;
            this.btnThemSach.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(130)))), ((int)(((byte)(71)))));
            this.btnThemSach.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(121)))), ((int)(((byte)(66)))));
            this.btnThemSach.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThemSach.Font = new System.Drawing.Font("Sitka Display", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnThemSach.Location = new System.Drawing.Point(37, 300);
            this.btnThemSach.Name = "btnThemSach";
            this.btnThemSach.Size = new System.Drawing.Size(108, 38);
            this.btnThemSach.TabIndex = 12;
            this.btnThemSach.Text = "Thêm";
            this.btnThemSach.UseVisualStyleBackColor = false;
            this.btnThemSach.Click += new System.EventHandler(this.btnThemSach_Click);
            // 
            // txtTenSach
            // 
            this.txtTenSach.Font = new System.Drawing.Font("Sitka Display", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtTenSach.Location = new System.Drawing.Point(165, 15);
            this.txtTenSach.Name = "txtTenSach";
            this.txtTenSach.Size = new System.Drawing.Size(231, 28);
            this.txtTenSach.TabIndex = 6;
            // 
            // lblGiaTri
            // 
            this.lblGiaTri.AutoSize = true;
            this.lblGiaTri.Font = new System.Drawing.Font("Sitka Heading", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblGiaTri.Location = new System.Drawing.Point(99, 202);
            this.lblGiaTri.Name = "lblGiaTri";
            this.lblGiaTri.Size = new System.Drawing.Size(60, 23);
            this.lblGiaTri.TabIndex = 5;
            this.lblGiaTri.Text = "Giá Trị";
            // 
            // lblNhaPhatHanh
            // 
            this.lblNhaPhatHanh.AutoSize = true;
            this.lblNhaPhatHanh.Font = new System.Drawing.Font("Sitka Heading", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblNhaPhatHanh.Location = new System.Drawing.Point(43, 167);
            this.lblNhaPhatHanh.Name = "lblNhaPhatHanh";
            this.lblNhaPhatHanh.Size = new System.Drawing.Size(116, 23);
            this.lblNhaPhatHanh.TabIndex = 4;
            this.lblNhaPhatHanh.Text = "Nhà Phát Hành";
            // 
            // lblNamXB
            // 
            this.lblNamXB.AutoSize = true;
            this.lblNamXB.Font = new System.Drawing.Font("Sitka Heading", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblNamXB.Location = new System.Drawing.Point(48, 92);
            this.lblNamXB.Name = "lblNamXB";
            this.lblNamXB.Size = new System.Drawing.Size(111, 23);
            this.lblNamXB.TabIndex = 3;
            this.lblNamXB.Text = "Năm Xuất Bản";
            // 
            // lblNXB
            // 
            this.lblNXB.AutoSize = true;
            this.lblNXB.Font = new System.Drawing.Font("Sitka Heading", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblNXB.Location = new System.Drawing.Point(53, 130);
            this.lblNXB.Name = "lblNXB";
            this.lblNXB.Size = new System.Drawing.Size(106, 23);
            this.lblNXB.TabIndex = 2;
            this.lblNXB.Text = "Nhà Xuất Bản";
            // 
            // lblTacGia
            // 
            this.lblTacGia.AutoSize = true;
            this.lblTacGia.Font = new System.Drawing.Font("Sitka Heading", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblTacGia.Location = new System.Drawing.Point(92, 55);
            this.lblTacGia.Name = "lblTacGia";
            this.lblTacGia.Size = new System.Drawing.Size(62, 23);
            this.lblTacGia.TabIndex = 1;
            this.lblTacGia.Text = "Tác Giả";
            // 
            // lblTenSach
            // 
            this.lblTenSach.AutoSize = true;
            this.lblTenSach.Font = new System.Drawing.Font("Sitka Heading", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblTenSach.Location = new System.Drawing.Point(86, 18);
            this.lblTenSach.Name = "lblTenSach";
            this.lblTenSach.Size = new System.Drawing.Size(73, 23);
            this.lblTenSach.TabIndex = 0;
            this.lblTenSach.Text = "Tên Sách";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(54)))), ((int)(((byte)(50)))));
            this.panel7.Controls.Add(this.button5);
            this.panel7.Controls.Add(this.checkBox1);
            this.panel7.Controls.Add(this.checkBox2);
            this.panel7.Controls.Add(this.checkBox3);
            this.panel7.Controls.Add(this.checkBox4);
            this.panel7.Controls.Add(this.checkBox5);
            this.panel7.Controls.Add(this.label11);
            this.panel7.Location = new System.Drawing.Point(6, 261);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(400, 211);
            this.panel7.TabIndex = 35;
            // 
            // button5
            // 
            this.button5.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Sitka Text", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.button5.ForeColor = System.Drawing.Color.White;
            this.button5.Location = new System.Drawing.Point(247, 148);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(104, 32);
            this.button5.TabIndex = 6;
            this.button5.Text = "Lọc";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Checked = true;
            this.checkBox1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox1.Font = new System.Drawing.Font("Sitka Subheading", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.checkBox1.ForeColor = System.Drawing.Color.White;
            this.checkBox1.Location = new System.Drawing.Point(202, 86);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(125, 25);
            this.checkBox1.TabIndex = 5;
            this.checkBox1.Text = "Ngày Đăng Ký";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Checked = true;
            this.checkBox2.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox2.Font = new System.Drawing.Font("Sitka Subheading", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.checkBox2.ForeColor = System.Drawing.Color.White;
            this.checkBox2.Location = new System.Drawing.Point(202, 55);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(97, 25);
            this.checkBox2.TabIndex = 4;
            this.checkBox2.Text = "Ngày Sinh";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Checked = true;
            this.checkBox3.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox3.Font = new System.Drawing.Font("Sitka Subheading", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.checkBox3.ForeColor = System.Drawing.Color.White;
            this.checkBox3.Location = new System.Drawing.Point(41, 117);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(142, 25);
            this.checkBox3.TabIndex = 3;
            this.checkBox3.Text = "Chứng Minh Thư";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Checked = true;
            this.checkBox4.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox4.Font = new System.Drawing.Font("Sitka Subheading", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.checkBox4.ForeColor = System.Drawing.Color.White;
            this.checkBox4.Location = new System.Drawing.Point(41, 86);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(120, 25);
            this.checkBox4.TabIndex = 2;
            this.checkBox4.Text = "Số Điện Thoại";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Checked = true;
            this.checkBox5.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox5.Font = new System.Drawing.Font("Sitka Subheading", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.checkBox5.ForeColor = System.Drawing.Color.White;
            this.checkBox5.Location = new System.Drawing.Point(41, 55);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(76, 25);
            this.checkBox5.TabIndex = 1;
            this.checkBox5.Text = "Địa Chỉ";
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Sitka Heading", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(20, 21);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(179, 28);
            this.label11.TabIndex = 0;
            this.label11.Text = "Thông Tin Cần Xem";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(54)))), ((int)(((byte)(50)))));
            this.panel8.Controls.Add(this.textBox6);
            this.panel8.Controls.Add(this.label12);
            this.panel8.Controls.Add(this.button6);
            this.panel8.Controls.Add(this.comboBox1);
            this.panel8.Location = new System.Drawing.Point(6, 261);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(400, 212);
            this.panel8.TabIndex = 34;
            // 
            // textBox6
            // 
            this.textBox6.BackColor = System.Drawing.Color.White;
            this.textBox6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox6.Font = new System.Drawing.Font("Sitka Text", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.textBox6.Location = new System.Drawing.Point(25, 63);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(181, 21);
            this.textBox6.TabIndex = 11;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Sitka Heading", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(20, 22);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(95, 28);
            this.label12.TabIndex = 10;
            this.label12.Text = "Tìm Kiếm";
            // 
            // button6
            // 
            this.button6.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Sitka Heading", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.button6.ForeColor = System.Drawing.Color.White;
            this.button6.Location = new System.Drawing.Point(240, 148);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(111, 36);
            this.button6.TabIndex = 7;
            this.button6.Text = "Tìm kiếm";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // comboBox1
            // 
            this.comboBox1.BackColor = System.Drawing.Color.White;
            this.comboBox1.Font = new System.Drawing.Font("Sitka Text", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Mã độc giả",
            "Tên độc giả",
            "CMND",
            "Số điện thoại"});
            this.comboBox1.Location = new System.Drawing.Point(25, 90);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(123, 29);
            this.comboBox1.TabIndex = 8;
            this.comboBox1.Text = "Tìm kiếm theo";
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(54)))), ((int)(((byte)(50)))));
            this.panel9.Controls.Add(this.pnlHighLightTimKiemSach);
            this.panel9.Controls.Add(this.pnlHighLightBoLoc);
            this.panel9.Controls.Add(this.tabbtnTimKiemSach);
            this.panel9.Controls.Add(this.tabbtnBoLocSach);
            this.panel9.Location = new System.Drawing.Point(6, 475);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(400, 40);
            this.panel9.TabIndex = 33;
            // 
            // pnlHighLightTimKiemSach
            // 
            this.pnlHighLightTimKiemSach.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(54)))), ((int)(((byte)(50)))));
            this.pnlHighLightTimKiemSach.Location = new System.Drawing.Point(0, 33);
            this.pnlHighLightTimKiemSach.Name = "pnlHighLightTimKiemSach";
            this.pnlHighLightTimKiemSach.Size = new System.Drawing.Size(200, 7);
            this.pnlHighLightTimKiemSach.TabIndex = 35;
            // 
            // pnlHighLightBoLoc
            // 
            this.pnlHighLightBoLoc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(54)))), ((int)(((byte)(50)))));
            this.pnlHighLightBoLoc.Location = new System.Drawing.Point(202, 33);
            this.pnlHighLightBoLoc.Name = "pnlHighLightBoLoc";
            this.pnlHighLightBoLoc.Size = new System.Drawing.Size(200, 7);
            this.pnlHighLightBoLoc.TabIndex = 36;
            // 
            // tabbtnTimKiemSach
            // 
            this.tabbtnTimKiemSach.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(54)))), ((int)(((byte)(50)))));
            this.tabbtnTimKiemSach.FlatAppearance.BorderSize = 0;
            this.tabbtnTimKiemSach.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.tabbtnTimKiemSach.Font = new System.Drawing.Font("Sitka Subheading", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.tabbtnTimKiemSach.ForeColor = System.Drawing.Color.White;
            this.tabbtnTimKiemSach.Location = new System.Drawing.Point(0, 0);
            this.tabbtnTimKiemSach.Name = "tabbtnTimKiemSach";
            this.tabbtnTimKiemSach.Size = new System.Drawing.Size(200, 33);
            this.tabbtnTimKiemSach.TabIndex = 29;
            this.tabbtnTimKiemSach.Text = "Tìm Kiếm";
            this.tabbtnTimKiemSach.UseVisualStyleBackColor = false;
            // 
            // tabbtnBoLocSach
            // 
            this.tabbtnBoLocSach.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(54)))), ((int)(((byte)(50)))));
            this.tabbtnBoLocSach.FlatAppearance.BorderSize = 0;
            this.tabbtnBoLocSach.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.tabbtnBoLocSach.Font = new System.Drawing.Font("Sitka Subheading", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.tabbtnBoLocSach.ForeColor = System.Drawing.Color.White;
            this.tabbtnBoLocSach.Location = new System.Drawing.Point(200, 0);
            this.tabbtnBoLocSach.Name = "tabbtnBoLocSach";
            this.tabbtnBoLocSach.Size = new System.Drawing.Size(200, 33);
            this.tabbtnBoLocSach.TabIndex = 30;
            this.tabbtnBoLocSach.Text = "Bộ Lọc";
            this.tabbtnBoLocSach.UseVisualStyleBackColor = false;
            // 
            // frmDocGia
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1021, 572);
            this.Controls.Add(this.pnltabKhoSach);
            this.Controls.Add(this.pnltabDocGia);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmDocGia";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.frmDocGia_Load);
            this.panel3.ResumeLayout(false);
            this.pnltabDocGia.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDocGia)).EndInit();
            this.pnlThongTinDocGia.ResumeLayout(false);
            this.pnlThongTinDocGia.PerformLayout();
            this.pnlThongBaoDocGia.ResumeLayout(false);
            this.pnlThongBaoDocGia.PerformLayout();
            this.pnlBoLoc.ResumeLayout(false);
            this.pnlBoLoc.PerformLayout();
            this.pnlSearchFor.ResumeLayout(false);
            this.pnlSearchFor.PerformLayout();
            this.pnlTacVu.ResumeLayout(false);
            this.pnltabKhoSach.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSach)).EndInit();
            this.pnlThongTinSach.ResumeLayout(false);
            this.pnlThongTinSach.PerformLayout();
            this.pnlThongBaoSach.ResumeLayout(false);
            this.pnlThongBaoSach.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button mainbtnKhoSach;
        private System.Windows.Forms.Button mainbtnCaiDat;
        private System.Windows.Forms.Button mainbtnQuyDinh;
        private System.Windows.Forms.Button mainbtnThongKe;
        private System.Windows.Forms.Button mainbtnNhanTraSach;
        private System.Windows.Forms.Button mainbtnChoMuonSach;
        private System.Windows.Forms.Button mainbtnDocGia;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel pnltabDocGia;
        private System.Windows.Forms.Button btnXoaDocGia;
        private System.Windows.Forms.Button btnThemDocGia;
        private System.Windows.Forms.Button btnSuaDocGia;
        private System.Windows.Forms.Panel pnlThongTinDocGia;
        private System.Windows.Forms.TextBox txtCMNDDocGia;
        private System.Windows.Forms.TextBox txtSDTDocGia;
        private System.Windows.Forms.TextBox txtDiaChiDocGia;
        private System.Windows.Forms.TextBox txtHoTenDocGia;
        private System.Windows.Forms.Label lblNgayDK;
        private System.Windows.Forms.Label lblNgaySinh;
        private System.Windows.Forms.Label lblSDT;
        private System.Windows.Forms.Label lblCMND;
        private System.Windows.Forms.Label lblDiaChi;
        private System.Windows.Forms.Label lblHoTen;
        private System.Windows.Forms.Panel pnlBoLoc;
        private System.Windows.Forms.Button btnLoc;
        private System.Windows.Forms.CheckBox chkNgayDK;
        private System.Windows.Forms.CheckBox chkNgaySinh;
        private System.Windows.Forms.CheckBox chkCMND;
        private System.Windows.Forms.CheckBox chkSDT;
        private System.Windows.Forms.CheckBox chkDiaChi;
        private System.Windows.Forms.Label lblTuaDe;
        private System.Windows.Forms.Panel pnlSearchFor;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label lblTimKiem;
        private System.Windows.Forms.Button btnSearchFor;
        private System.Windows.Forms.ComboBox cboSearchFor;
        private System.Windows.Forms.DataGridView dgvDocGia;
        private System.Windows.Forms.DateTimePicker dtmNgayDKDocGia;
        private System.Windows.Forms.DateTimePicker dtmNgaySinhDocGia;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblThongBaoDocGia;
        private System.Windows.Forms.Button btnHuyThaoTacDocGia;
        private System.Windows.Forms.Panel pnlThongBaoDocGia;
        private System.Windows.Forms.Label lblTitleThongBaoDocGia;
        private System.Windows.Forms.Panel pnlTacVu;
        private System.Windows.Forms.Panel pnlHightLightTimKiem;
        private System.Windows.Forms.Panel pnlHightLightBoLoc;
        private System.Windows.Forms.Button tabbtnTimKiemDocGia;
        private System.Windows.Forms.Button tabbtnBoLocDocGia;
        private System.Windows.Forms.Panel pnltabKhoSach;
        private System.Windows.Forms.DataGridView dgvSach;
        private System.Windows.Forms.Panel pnlThongTinSach;
        private System.Windows.Forms.Panel pnlThongBaoSach;
        private System.Windows.Forms.Label lblTitleThongBaoSach;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnHuyCapNhatSach;
        private System.Windows.Forms.Label lblCapNhatDocGia;
        private System.Windows.Forms.TextBox txtNXB;
        private System.Windows.Forms.TextBox txtNamXB;
        private System.Windows.Forms.Button btnSuaSach;
        private System.Windows.Forms.Button btnXoaSach;
        private System.Windows.Forms.TextBox txtTacGia;
        private System.Windows.Forms.Button btnThemSach;
        private System.Windows.Forms.TextBox txtTenSach;
        private System.Windows.Forms.Label lblGiaTri;
        private System.Windows.Forms.Label lblNhaPhatHanh;
        private System.Windows.Forms.Label lblNamXB;
        private System.Windows.Forms.Label lblNXB;
        private System.Windows.Forms.Label lblTacGia;
        private System.Windows.Forms.Label lblTenSach;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel pnlHighLightTimKiemSach;
        private System.Windows.Forms.Panel pnlHighLightBoLoc;
        private System.Windows.Forms.Button tabbtnTimKiemSach;
        private System.Windows.Forms.Button tabbtnBoLocSach;
        private System.Windows.Forms.TextBox txtNhaPhatHanh;
        private System.Windows.Forms.TextBox txtGiaTri;
        private System.Windows.Forms.TextBox txtSoLuong;
        private System.Windows.Forms.Label lblSoLuong;
        private System.Windows.Forms.Label lblMaChuDe;
        private System.Windows.Forms.TextBox txtMaChuDe;
        private System.Windows.Forms.Label lblNgayNhap;
        private System.Windows.Forms.Label lblMaTheLoai;
        private System.Windows.Forms.TextBox txtMaTheLoai;
        private System.Windows.Forms.DateTimePicker dtmNgayNhap;
        private System.Windows.Forms.Label lblThongBaoSach;
    }
}